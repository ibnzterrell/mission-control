

exports.handler = (req, res) => {
    res.send('Hello, Mars!');
};